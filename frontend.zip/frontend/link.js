/ Display generated link
            const generatedLink = window.location.href;
            document.getElementById("linkDisplay").textContent = generatedLink;

            // Copy link functionality
            document.getElementById("copyBtn").addEventListener("click", function () {
              navigator.clipboard.writeText(generatedLink)
                .then(() => {
                  document.getElementById("copyAlert").style.display = "block";
                  setTimeout(() => {
                    document.getElementById("copyAlert").style.display = "none";
                  }, 2000);
                })
                .catch(() => {
                  alert("Failed to copy the link.");
                });
            });